import React from 'react';

function Header() {

  return(
    <div className='bg-slate-200 font-bold text-center m-auto h-24'>
      <p>Header</p>
    </div>
  )

}


export default Header;