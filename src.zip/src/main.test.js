import { render, screen, waitFor, act } from '@testing-library/react';
import Main from './main'; // import your Main component

/*
it('renders "No Record!" when there are no records', async () => {
  render(<Main />);

  // Wait for any async actions to complete
  await screen.findByText('No Record!');

  expect(screen.getByText('No Record!')).toBeInTheDocument();
});
*/


describe("withFetch2", () => {
  it('can fetch normally', async () => {  
    render(<Main />);

    await waitFor(() => screen.getByText('H6588002'));

    expect(screen.getByText('H6588002')).toBeInTheDocument();
    
    screen.debug();
  });
});  


