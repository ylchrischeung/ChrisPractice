import React from 'react';
import Data from './data.json';
import Product from './components/Product';

class App extends React.Component{
  render(){
    return(
      <>
        <header>
          <h1 className="text">Products</h1>
        </header>
        <div className="products-container">
          {Data.products.map((product,i) => <Product key={i} product={product}/>)}
        </div>
      </>
    );
  }
}
export default App;
