import React  from 'react';
import Preview from './Preview';
class Product extends React.Component{
    constructor(props){
        super(props);
        this.state ={
            previewStatus : false
        }
    }
    Handlechange(){
        this.setState({previewStatus : !this.state.previewStatus})
    }
    render(){
        return(
            <div className="product">
                <img src={this.props.product.images[0].url} alt="error"/>
                <h3>{this.props.product.name}</h3>
                <div className="bt-container">
                    <button onClick={this.Handlechange.bind(this)} className="preview">{this.state.previewStatus?'Preview':'Preview'}</button>
                    {this.state.previewStatus ?
                    <Preview className="preview-info active"code={this.props.product.code}/>:
                    <Preview className="preview-info"code={this.props.product.code}/>}
                    <button className="detail">Detail{console.log(this.props.product.description)}</button>
                </div>
            </div>
        );
    }
}
export default Product;