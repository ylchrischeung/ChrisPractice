import React from 'react';

class Preview extends React.Component{
    constructor(props){
        super(props);
        this.state = {
            isClick : false
        };
    }
    handleClick(){
        this.setState({isClick : !this.state.isClick})
    }
    render(){
        return(
            <div className={this.props.className}>
                <h2 className="code">{this.props.code}</h2>
                <button className="select" onClick={this.handleClick.bind(this)}>Select</button>     
            </div>
        );
    }
}
export default Preview;